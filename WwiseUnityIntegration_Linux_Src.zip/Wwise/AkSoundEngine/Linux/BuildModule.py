# Linux Wwise Unity Build module
import BuildUtil
import BuildWwiseUnityIntegration
import GenerateApiBinding
import platform
import os
from os import path
from BuildWwiseUnityIntegration import MultiArchBuilder
from GenerateApiBinding import GccSwigCommand
from PrepareSwigInput import SwigPlatformHandlerPOSIX, SwigApiHeaderBlobber, PlatformStructProfile

class LinuxBuilder(MultiArchBuilder):
	def __init__(self, platformName, arches, configs, generateSwig, generatePremake):
		MultiArchBuilder.__init__(self, platformName, arches, configs, generateSwig, generatePremake)
		self.compiler = 'make'
		self.solution = 'AkSoundEngineLinux.make'

	def generate_cross_compilation_toolchain_cmd(self, target, sysroot, config_string):
		cmd = ['make', '-f', self.solution, '-k', config_string]

		cmd.append(f'CXXFLAGS=-target {target} --sysroot={sysroot} -nostdinc++ -I{sysroot}/usr/include/c++/v1')
		cmd.append(f'CFLAGS=-target {target} --sysroot={sysroot}')
		cmd.append(f'LDFLAGS=-target {target} --sysroot={sysroot}')
		cmd.append('EXTRA_LDFLAGS=-nostdlib++ -lc++ -lc++abi')
		cmd.append('AR=llvm-ar')

		return cmd

	def _CreateCommands(self, arch=None, config='Profile'):
		config_string = f"config={config.lower()}_x64"
		cmd = []

		if platform.system() == 'Windows':
			linux_multiarch_root = os.environ.get('LINUX_MULTIARCH_ROOT', None)
			if linux_multiarch_root is None:
				raise RuntimeError('LINUX_MULTIARCH_ROOT environment variable is required for Linux build on Windows!')

			arch_to_clangtarget = {
				"aarch64" : "aarch64-unknown-linux-gnueabi",
				"x86_64" : "x86_64-unknown-linux-gnu"
			}

			clangtarget = arch_to_clangtarget[arch]
			sysroot = os.path.join(linux_multiarch_root, clangtarget)
			cmd = self.generate_cross_compilation_toolchain_cmd(clangtarget, sysroot, config_string)
			os.environ['PATH'] = os.path.join(sysroot, "bin") + os.pathsep + os.environ['PATH']
		elif platform.system() == "Linux":
			cmd = ['schroot', '--chroot', "steamrt_scout_amd64", '--', self.compiler, '-f', self.solution, config_string]
		else:
			raise NotImplementedError()
		
		return [cmd]

	def _RunCommands(self, cmds):
		previous_cwd = os.getcwd()
		os.chdir('../Linux')
		isSuccess = MultiArchBuilder._RunCommands(self, cmds)
		os.chdir(previous_cwd)
		return isSuccess
		
class LinuxSwigCommand(GccSwigCommand):
	def __init__(self, pathMan):
		GccSwigCommand.__init__(self, pathMan)
		self.compilerDefines += ['-D__linux__']
		self.platformDefines += ['-DAK_LINUX']
	
class SwigApiHeaderBlobberLinux(SwigApiHeaderBlobber):
	def __init__(self, pathMan):
		SwigApiHeaderBlobber.__init__(self, pathMan)

		self.inputHeaders.append(path.normpath(path.join(self.SdkIncludeDir, 'AK/SoundEngine/Platforms/Linux/AkLinuxSoundEngine.h')))

class SwigPlatformHandlerLinux(SwigPlatformHandlerPOSIX):
	def __init__(self, pathMan):
		SwigPlatformHandlerPOSIX.__init__(self, pathMan)
		ThreadPropertyHeader = 'AK/Tools/Linux/AkPlatformFuncs.h'

def Init(argv=None):
	BuildUtil.BankPlatforms['Linux'] = 'Linux'
	BuildUtil.SupportedArches['Linux'] = ['x86_64']
	BuildUtil.PremakeParameters['Linux'] = { 'os': 'linux', 'generator': 'gmake' }
	BuildUtil.PlatformSwitches['Linux'] = '#if UNITY_STANDALONE_LINUX && ! UNITY_EDITOR'
	BuildUtil.SupportedPlatforms['Windows'].append('Linux')
	BuildUtil.SupportedPlatforms['Linux'].append('Linux')

def CreatePlatformBuilder(platformName, arches, configs, generateSwig, generatePremake):
	return LinuxBuilder(platformName, arches, configs, generateSwig, generatePremake)

def CreateSwigCommand(pathMan, arch):
	return LinuxSwigCommand(pathMan)

def CreateSwigPlatformHandler(pathMan):
	return SwigPlatformHandlerLinux(pathMan)

def CreateSwigApiHeaderBlobber(pathMan):
	return SwigApiHeaderBlobberLinux(pathMan)

if __name__ == '__main__':
	pass
